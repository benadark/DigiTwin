import pandas as pd
from datetime import datetime
df = pd.read_excel('aqi11.xlsx', usecols="C,D")#cols C has Datetime and D has AQI's
# Create new columns
df['year'] = df['Datetime'].dt.year
df['month'] = df['Datetime'].dt.month
df['day'] = df['Datetime'].dt.day
df['hour'] = df['Datetime'].dt.hour
df['seconds']=df
df.to_excel('ml_epa_aqi.xlsx',index = False)