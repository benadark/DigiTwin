import pickle
import boto3
session = boto3.session.Session(region_name='us-east-1')
s3client = session.client('s3')
bucket='digitwin-airqualitydata'
key='EPA_data/EPA_rfr.sav'
response = s3client.get_object(Bucket=bucket, Key=key)

body_string = response['Body'].read()
rfr = pickle.loads(body_string)


a=input("Enter year(yyyy): ")
b=input("Enter month(1-12): ")
c=input("Enter day(1-31): ")
d=input("Enter hour(0-23): ")
g=input("Enter min(0-60): ")
h=input("Enter sec(0-60): ")
e=input("Day of the Week(1=Sun,2=Mon,3=Tues,4=Wed,5=Thur,6=Fri,7=Sat): ")
if e!=7 or e!=1:
    f=False
else:
    f=True
x_t=[[a,c,d,g,h,e,f,b]]
predicted_aqi=rfr.predict(x_t)
print("Predicted AQI:",predicted_aqi)