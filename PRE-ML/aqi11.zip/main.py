
import pandas as pd
import xlsxwriter
from datetime import datetime
#import datetime

my_xcl = pd.read_excel('aqi11.xlsx', usecols="C,D")
myxcl = my_xcl.copy()
myxcl.set_index(['Datetime'],inplace=True)
myxcl1=myxcl.between_time('06:00', '18:00',include_end = False)
myxcl2=myxcl.between_time('18:00','06:00',include_end = False)

#print(myxcl.loc['2019-12-31 23:00:00'])
#myxcl.astype(float)
my_csv4=myxcl.resample('B').mean() #weekday avg
my_csv2=myxcl.resample('M').mean() #monthly avg
my_csv3 = myxcl.resample('D').mean()#daily avg
mycsv3_1=myxcl1.resample('D').mean() #day avg for each day
mycsv3_2=myxcl2.resample('D').mean() #night avg for each day
my_csv6=myxcl.resample('w').mean()#weekly avg

"""
data={
        "DateTime":s,
        "AQI":p
      }
my_csv5=pd.DataFrame(data)
"""

writer = pd.ExcelWriter('baseline.xlsx', engine='xlsxwriter')
# Write each dataframe to a different worksheet.
my_csv2.to_excel(writer, sheet_name='MONTH')
my_csv3.to_excel(writer, sheet_name='DAY')
my_csv4.to_excel(writer, sheet_name='WEEKDAY')
my_csv6.to_excel(writer, sheet_name='WEEKLY')
mycsv3_1.to_excel(writer, sheet_name='DA_Y')
mycsv3_2.to_excel(writer, sheet_name='Night')
#my_csv5.to_excel(writer, sheet_name='WEEKEND')
#my_csv1.to_excel(writer, sheet_name='Sheet3')

# Close the Pandas Excel writer and output the Excel file.
writer.save()


