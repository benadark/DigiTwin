import pandas as pd
#import datetime

my_xcl = pd.read_excel('aqi1.xlsx', usecols="C,D")
myxcl = my_xcl.copy()
print(myxcl.loc[0])
for k in range(len(myxcl["AQI"])):
  
"""
myxcl.set_index(['DateTime'],inplace=True)
print(myxcl.loc['2019-12-31 23:00:00'])
myxcl.astype(float)
my_csv3 = myxcl.resample('D').mean()
"""
