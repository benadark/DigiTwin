import urllib,json,urllib.request
#test
#url="https://aqs.epa.gov/data/api/sampleData/byCounty?email=benadark@terpmail.umd.edu&key=aquakit86&param=88101&bdate=20190101&edate=20191231&state=24&county=033"

#URL1 contains PM2.5 values in Micrograms/cubic meter 
url1="https://aqs.epa.gov/data/api/sampleData/bySite?email=benadark@terpmail.umd.edu&key=aquakit86&param=88101&bdate=20190101&edate=20191231&state=11&county=001&site=0041"
#url2=""

response = urllib.request.urlopen(url1)
data = json.loads(response.read())
with open('chevy_PM2_5.json', 'w') as f:
    json.dump(data, f) #dump json data  into a file

