import math
import pandas as pd


def aqiFromPM(pm):

      if math.isnan(pm): return "-" 
      if pm == None :return "-"
      if pm < 0: return pm 
      if pm > 1000: return "-" 
        
      """ 
       Good   0 - 50         0.0 - 15.0         0.0 – 12.0
        Moderate          51 - 100           >15.0 - 40        12.1 – 35.4
        Unhealthy for Sensitive Groups   101 – 150     >40 – 65          35.5 – 55.4
        Unhealthy                                 151 – 200         > 65 – 150       55.5 – 150.4
        Very Unhealthy                    201 – 300 > 150 – 250     150.5 – 250.4
        Hazardous                                 301 – 400         > 250 – 350     250.5 – 350.4
        Hazardous                                 401 – 500         > 350 – 500     350.5 – 500 
        """
      if pm > 350.5: 
          return calcAQI(pm, 500, 401, 500, 350.5)
      elif pm > 250.5:
          return calcAQI(pm, 400, 301, 350.4, 250.5)
      elif pm > 150.5:
          return calcAQI(pm, 300, 201, 250.4, 150.5)
      elif pm > 55.5:
          return calcAQI(pm, 200, 151, 150.4, 55.5)
      elif pm > 35.5:
          return calcAQI(pm, 150, 101, 55.4, 35.5)
      elif pm > 12.1: 
          return calcAQI(pm, 100, 51, 35.4, 12.1)
      elif pm >= 0: 
          return calcAQI(pm, 50, 0, 12, 0)
      else :
          return None
        
      
#Function to calculate BPL from PM      
def bplFromPM(pm) :
        if math.isnan(pm): return 0 
        if pm == None: return 0;
        if (pm < 0): return 0; 
        """      
              Good                              0 - 50         0.0 - 15.0         0.0 – 12.0
        Moderate                        51 - 100           >15.0 - 40        12.1 – 35.4
        Unhealthy for Sensitive Groups   101 – 150     >40 – 65          35.5 – 55.4
        Unhealthy                                 151 – 200         > 65 – 150       55.5 – 150.4
        Very Unhealthy                    201 – 300 > 150 – 250     150.5 – 250.4
        Hazardous                                 301 – 400         > 250 – 350     250.5 – 350.4
        Hazardous                                 401 – 500         > 350 – 500     350.5 – 500
        """
        if pm > 350.5: return 401
        elif pm > 250.5:return 301
        elif (pm > 150.5): return 201
        elif (pm > 55.5): return 151
        elif (pm > 35.5): return 101
        elif (pm > 12.1): return 51
        elif (pm >= 0): return 0
        else : return 0
      
def bphFromPM(pm):
      #return 0;
      if (math.isnan(pm)): return 0 
      if (pm == None): return 0
      if (pm < 0): return 0 
      """
       Good   0 - 50         0.0 - 15.0         0.0 – 12.0
       Moderate   51 - 100           >15.0 - 40        12.1 – 35.4
        Unhealthy for Sensitive Groups   101 – 150     >40 – 65          35.5 – 55.4
        Unhealthy                       151 – 200         > 65 – 150       55.5 – 150.4
        Very Unhealthy                    201 – 300 > 150 – 250     150.5 – 250.4
        Hazardous                         301 – 400         > 250 – 350     250.5 – 350.4
        Hazardous                         401 – 500         > 350 – 500     350.5 – 500
      """
      if pm > 350.5: return 500
      elif pm > 250.5:return 500
      elif pm > 150.5:return 300
      elif pm > 55.5 :return 200
      elif pm > 35.5 :return 150
      elif pm > 12.1 :return 100
      elif pm >= 0:return 50
      else: return 0
        

 
def calcAQI(Cp, Ih, Il, BPh, BPl) :
      
         a = (Ih - Il);
         b = (BPh - BPl);
         c = (Cp - BPl);
         return round((a/b) * c + Il)
       
############################################################################



my_csv = pd.read_csv('chillum_rdata.csv') #contains PM2.5 hourly from 01/01/2019 to 12/31/2019
column = my_csv['PM2.5_CF1_ug/m3']
column2=my_csv['created_at']
print(type(column),"\n",len(column))
L= [];l=[] #empty list to store dates and PM2.5 values

for i in range(len(column)):
  if column[i]>1000 or math.isnan(column[i]):
    continue
  else:
   l.append(column2[i])
   x=aqiFromPM(column[i])
   L.append(x)
#Data is a dictionary containing the valid dates and AQI's
#The invalid PM values and out of range have been taken out 
data = {
  "Date": l,
  "AQI": L
}
df=pd.DataFrame(data)
df.to_csv('chillum_aqi_hourly_purple.csv',index = False)

"""
#Calculate AQI from PM2.5 of River Terrace EPA data
my_csv1=pd.read_csv('River_Terrace_PM25_EPA.csv') 
c1=my_csv1['sample_measurement'] #storing PM 2.5 values into c1
c2=[my_csv1['date_local'],my_csv1['time_local']] #storing local date and time 

#Empty Lists
C1=[] #storing aqi from Pm2.5
C2=[] #storing local date
C3=[] #storing local time
for i in range(len(c1)):
  if c1[i]>1000 or math.isnan(c1[i]):
    continue
  else:
   C3.append(c2[1][i])
   C2.append(c2[0][i])
   C1.append(aqiFromPM(c1[i]))
   
#Data is a dictionary containing the valid dates and AQI's
#The invalid PM values and out of range have been taken out 
data1 = {
  "Local Date": C2,
  "Local Time":C3,
  "AQI":C1 
}
df=pd.DataFrame(data1)
df.to_csv('aqi1.csv',index = False)
"""

