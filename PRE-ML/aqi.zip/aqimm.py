#aqi library for PM to AQI algorthism
import aqi

#Pandas used to read excel file
import pandas as pd

import xlsxwriter

from openpyxl import Workbook

import csv

#import the excel file (sample file creates called "practice" which stores 5 random numbers)
cols = [2]

df = pd.read_csv ('chevyair.csv')
column=df['PM2.5_CF1_ug/m3']

#convnert DataFrame to a list
list = df.values.tolist()

myaqi = []
#Loop each number from excel file through function
        #nested loop used for list of lists
for i in list:
    for number in i:
        myaqi.append(aqi.to_iaqi(aqi.POLLUTANT_PM25, number, algo=aqi.ALGO_EPA))
        
        df = pd.DataFrame(myaqi)

        writer = pd.ExcelWriter('Cheverly_AQI_data_PM25.xlsx', engine='xlsxwriter')

        #     # Convert the dataframe to an XlsxWriter Excel object.
        df.to_excel(writer, sheet_name='AQI PM2.5')

        #     # Close the Pandas Excel writer and output the Excel file.
        writer.save()


        #print(type(myaqi))
        #float_number.to_csv('./AQI_m.xlsx', sheet_name='AQI_value')
       

#sample of function where PM value equals 12
#myaqi = aqi.to_iaqi(aqi.POLLUTANT_PM25, '12', algo=aqi.ALGO_EPA)
